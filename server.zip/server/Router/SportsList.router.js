const express = require('express');
const router = express.Router();
const sportsListController = require('../Controller/sportsList.Controller');

// GET request: /api/sportslist/:id
router.get('/:id', sportsListController.getSportsList);

module.exports = router;
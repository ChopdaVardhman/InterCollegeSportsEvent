const { sql, poolPromise } = require('../Config/db');

class SportsList {
  static async getSportsListById(categoryId) {
    const pool = await poolPromise;
    const request = pool.request();

    request.input('categoryId', sql.Int, categoryId);

    const query = `
      SELECT Sport_ID, Sport_Name
      FROM [dbo].[TBL_Sports_Master]
      WHERE Category_ID = @categoryId;
    `;

    const result = await request.query(query);
    // Pura array return karein taaki us category ke sabhi sports milein
    return result.recordset || [];
  }
}

module.exports = SportsList;